document.querySelector('.buy-btn').addEventListener('click', function() {
    alert('Buy button clicked! (Yahan pe cart logic ayega)');
});
